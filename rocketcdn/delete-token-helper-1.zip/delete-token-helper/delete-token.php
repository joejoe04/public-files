<?php
/**
 * Plugin Name: WP Rocket | Delete RocketCDN Token
 * Description: delete the RocketCDN Token
 * Author:      WP Rocket Support Team
 * Author URI:  http://wp-rocket.me/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2020
 */

namespace WP_Rocket\Helpers\rocketcdn\token;

// Standard plugin security, keep this line in place.
defined( 'ABSPATH' ) or die();

function delete_token(){
	return delete_option( 'rocketcdn_user_token' );

}

register_activation_hook( __FILE__, __NAMESPACE__ . '\delete_token' );