<?php
/**
 * Plugin Name: WP Rocket | Log API calls
 * Plugin URI:  https://wp-rocket.me/
 * Description: Log our API calls, easy to debug license and reports responses.
 * Author:      Ahmed Saeed
 * Author URI:  https://wp-rocket.me/
 * Version:     0.1
 * License:     GPLv2 or later (license.txt)
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class WPR_Log_API_Main {

	private static $_instance = null;

	public static function get_instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function add_hooks() {
		//add_action( '' );
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'http_api_debug', [ $this, 'log_api' ], 10, 5 );
		add_action( 'add_meta_boxes', [ $this, 'add_meta_box' ] );
	}

	public function register_post_type() {
		$labels = array(
			'name'          => _x( 'API Logs', 'Post type general name', 'wpr_api_log' ),
			'singular_name' => _x( 'Log', 'Post type singular name', 'wpr_api_log' ),
		);
		$args = array(
			'labels'             => $labels,
			'description'        => 'WP Rocket Helper API logs.',
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => 9999,
			'supports'           => array( 'title' ),
			'show_in_rest'       => true
		);

		register_post_type( 'wpr_api_log', $args );
	}

	public function log_api( $response, $context, $class, $parsed_args, $url ) {
		if ( ! strstr( $url, 'wp-rocket.me' ) ) {
			return;
		}

		$success = ! is_wp_error( $response );

		// Create post object
		$log_post = array(
			'post_title'    => esc_url( $url ) . ' - ' . ( $success ? 'Success' : 'Failure' ),
			'post_status'   => 'publish',
			'post_type'     =>  'wpr_api_log'
		);

		$log_post_id = wp_insert_post( $log_post );
		if ( is_wp_error( $log_post_id ) ) {
			return;
		}

		add_post_meta( $log_post_id, '_wpr_request_parsed_args', var_export( $parsed_args, true ) );
		add_post_meta( $log_post_id, '_wpr_response', var_export( $response, true ) );
        if ( ! $success ) {
            return;
        }
		add_post_meta( $log_post_id, '_wpr_response_code', var_export( wp_remote_retrieve_response_code( $response ), true ) );
		add_post_meta( $log_post_id, '_wpr_response_body', var_export( wp_remote_retrieve_body( $response ), true ) );
	}

	public function add_meta_box( $post_type ) {
		if ( 'wpr_api_log' !== $post_type ) {
			return;
		}

		add_meta_box(
			'wpr_api_log_metabox',
			__( 'API Request/Response Details', 'wpr_api_log' ),
			array( $this, 'render_meta_box_content' ),
			$post_type
		);
	}

	public function render_meta_box_content( $post ) {
		$parsed_args = get_post_meta( $post->ID, '_wpr_request_parsed_args', true );
		$response    = get_post_meta( $post->ID, '_wpr_response', true );
		$response_code    = get_post_meta( $post->ID, '_wpr_response_code', true );
		$response_body    = get_post_meta( $post->ID, '_wpr_response_body', true );

		?>
		<div>
			<strong>Parsed Args:</strong>
			<?php echo $parsed_args; ?>
		</div>
        <hr>
        <div>
            <strong>Response:</strong>
			<?php echo $response; ?>
        </div>
        <hr>
        <div>
            <strong>Response Code:</strong>
			<?php echo $response_code; ?>
        </div>
        <hr>
        <div>
            <strong>Response Body:</strong>
			<?php echo $response_body; ?>
        </div>
		<?php
	}

	public function deactivate() {
		//Delete all posts in this post type: wpr_api_log
		$allposts= get_posts( array('post_type'=>'wpr_api_log','numberposts'=>-1) );
		foreach ($allposts as $eachpost) {
			wp_delete_post( $eachpost->ID, true );
		}
	}

}

add_action( 'plugins_loaded', [ WPR_Log_API_Main::get_instance(), 'add_hooks' ] );
register_deactivation_hook( __FILE__, [ WPR_Log_API_Main::get_instance(), 'deactivate' ] );
