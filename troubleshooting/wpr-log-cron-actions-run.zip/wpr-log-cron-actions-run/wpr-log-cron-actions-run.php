<?php
/**
* Plugin Name: WP Rocket - Log Cron Actions Run
* Plugin URI: 
* Description: Creates log files including all fired cron hooks
* Author: 
* Author URI: 
* License: GPLv2 or later
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Action_Log_Cron_Runs' ) ) {
    
    class Action_Log_Cron_Runs {

        private static $_instance           = null;
        private static $cron_actions 		= array();
       
        public static function get_instance() {

            if( is_null( self::$_instance ) ){
                self::$_instance = new Action_Log_Cron_Runs();
            }
            return self::$_instance;
            
        }

        private function __construct() {

        	if ( empty( self::$cron_actions ) ) {
        		$this->list_cron_actions();
        		$this->hook_cron_actions();
        	}        	

        }

        private function list_cron_actions() {

        	$cron_jobs = get_option( 'cron' );

			foreach ( $cron_jobs as $key => $cron_job )  {
				
				if ( ! is_array( $cron_job ) || empty( $cron_job ) ) {
					continue;
				}

				self::$cron_actions[] = array_keys( $cron_job )[0];
			}

        }


        private function hook_cron_actions() {

        	foreach ( self::$cron_actions as $hook ) {
        		add_action( $hook, [ $this, 'log_action_triggered' ] );
        	}

        }


        public function log_action_triggered() {

        	$hook_name = current_filter();

        	if ( ! empty( $hook_name ) ) {
        		$this->log( $hook_name );
        	}

        }

        private function log( $message ) {

            $time = date( 'd-M-Y H:i:s' );

            error_log(
                "[ {$time} ] => {$message}\n\n",
                3,
                WP_CONTENT_DIR . "/wp-cronruns.log"
            );

        }


    }

    if ( ! function_exists( 'Action_log_cron_runs' ) ) {

        function Action_log_cron_runs() {
            return Action_Log_Cron_Runs::get_instance();
        };

        add_action( 'plugins_loaded', 'Action_log_cron_runs', 10 );
    }

}